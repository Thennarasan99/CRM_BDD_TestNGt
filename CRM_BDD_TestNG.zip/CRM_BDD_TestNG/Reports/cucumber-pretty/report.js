$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("D:/CRM_BDD_TestNG/src/test/resources/feature/Add_contacts.feature");
formatter.feature({
  "name": "feature to test Innova Website Status code functionality",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "check the Status code of Innova Website",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@ChcekStatusCode"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on homepage",
  "keyword": "Given "
});
formatter.match({
  "location": "Crm_addcontacts_automation.user_is_on_homepage()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});